
function SwitchViewToVoiceRoom() { 
    localStorage.clear();
    window.location.href = 'views/roomselection.html';
   
   }